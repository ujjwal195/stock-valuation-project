# papp/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.predict, name='predict'),  # Route the root URL to the predict view
    # You can add more URLs here if needed
]

