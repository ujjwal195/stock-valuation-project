from django.shortcuts import render
import pickle
import os
import pandas as pd
from django.http import JsonResponse


def predict(request):

    if request.method == 'POST':
        # Extract data from POST request
        price = float(request.POST.get('price'))
        change = float(request.POST.get('change'))
        percent_change = float(request.POST.get('percent_change'))
        volume = float(request.POST.get('volume'))
        avg_vol_3_month = float(request.POST.get('avg_vol_3_month'))
        market_cap = float(request.POST.get('market_cap'))

        # Load the trained model
        model_filename = 'rf_pipe.pkl'
        model_path = os.path.join(os.path.dirname(__file__), 'models', model_filename)
        # Load the trained model from the pickle file
        with open(model_path, 'rb') as model_file:
            model = pickle.load(model_file)

        # Perform prediction
        input_data = [[price, change, percent_change, volume, avg_vol_3_month, market_cap]]
        prediction = model.predict(input_data)


        return render(request, 'prediction_result.html', {'prediction': prediction[0]})
        # Return prediction as JSON response
        # return JsonResponse({'prediction': prediction[0]})

    # If request method is not POST, render the form template
    return render(request, 'predict.html')